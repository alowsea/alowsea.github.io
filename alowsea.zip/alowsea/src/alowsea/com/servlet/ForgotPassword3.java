package alowsea.com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import alowsea.com.dao.UseMethods;

/**
 * Servlet implementation class ForgotPassword3
 */
@WebServlet("/forgotPassword3")
public class ForgotPassword3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	HttpSession session = request.getSession();
	String username = (String)session.getAttribute("username");
    String password = request.getParameter("password");
    String passwordagain=request.getParameter("passwordagain");
	String regPw = "^\\w{6,18}$";
    if(password.equals(passwordagain)) {
    	if(password.matches(regPw)) {
    		UseMethods useMethods = new UseMethods();
        	useMethods.updatepassword(username, password);
        	response.sendRedirect("forgotpassword4.jsp");
    	}else {
    		request.setAttribute("msg", "������6-18λ����");
        	request.getRequestDispatcher("forgotpassword3.jsp").forward(request, response);;
    	}
    }
    else {
    	request.setAttribute("msg", "������������벻һ��");
    	request.getRequestDispatcher("forgotpassword3.jsp").forward(request, response);;
    }
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
