package alowsea.com.servlet;

import java.io.IOException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import alowsea.com.dao.UseMethods;

/**
 * Servlet implementation class ForgotPassword
 */
@WebServlet("/forgotPassword")
public class ForgotPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		UseMethods useMethods = new UseMethods();
		HttpSession session = request.getSession();
		String emailaddress = useMethods.emailaddress(username);
		if(emailaddress != null) {
			session.setAttribute("emailaddress",emailaddress);
			session.setAttribute("username", username);
			Random random = new Random();
			String code = "";
			for (int i=0;i<6;i++) {
			code += random.nextInt(10);
			}
			int result = useMethods.updatecode(emailaddress, code);
		    if(result>0) {
			String codes = useMethods.code(emailaddress);
			System.out.println(codes);
			session.setAttribute("code", codes);
			response.sendRedirect("forgotpassword2.jsp");
		}
		}
		else {
		request.setAttribute("msg", "��������û�������������������");
		request.getRequestDispatcher("/forgotpassword.jsp").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
