package alowsea.com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import alowsea.com.dao.UseMethods;
import alowsea.com.entity.Users;

@WebServlet("/registerServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String pwdagain = request.getParameter("pwdagain");
		String emailaddress = request.getParameter("emailaddress");
		UseMethods useMethods = new UseMethods();
		
		/*if (result > 0 && password.equals("pwdagain") && emailresult == 1) {
			response.sendRedirect("login.jsp");
		}*/
		/*
		 * else { request.setAttribute("msg", "���������Ϣ�Ѿ���ע��������ע��");
		 * request.getRequestDispatcher("/login.jsp").forward(request, response); }
		 */
		if(password.equals(pwdagain)) {
			System.out.println(4);
			int emailresult = useMethods.queryemail(emailaddress);
			if(emailresult == 0) {
				System.out.println(5);
				Users users = new Users(username, password, emailaddress);
				int result = useMethods.register(users);
				if(result >0) {
					System.out.println(6);
					response.sendRedirect("login.jsp");
				}
				else {
					System.out.println(3);
					request.setAttribute("msg", "��������û����ѱ�ע��");
					request.getRequestDispatcher("/login.jsp").forward(request, response); 
				}
			}
			else {
				System.out.println(2);
				request.setAttribute("msg", "������������ѱ�ע��");
				request.getRequestDispatcher("/login.jsp").forward(request, response); 
			}
		}
		else {
			System.out.println(1);
			request.setAttribute("msg", "����������벻һ��");
			request.getRequestDispatcher("/login.jsp").forward(request, response); 
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
