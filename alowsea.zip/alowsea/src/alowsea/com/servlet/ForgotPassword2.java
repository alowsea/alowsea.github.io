package alowsea.com.servlet;

import java.io.IOException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import alowsea.com.dao.UseMethods;

@WebServlet("/forgotPassword2")
public class ForgotPassword2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		/*
		 * String username = (String)session.getAttribute("username");
		 * System.out.println(username); UseMethods useMethods = new UseMethods();
		 * String emailaddress = useMethods.emailaddress(username);
		 * System.out.println(emailaddress);
		 * session.setAttribute("emailaddress",emailaddress); Random random = new
		 * Random(); String code = ""; for (int i=0;i<6;i++) { code +=
		 * random.nextInt(10); } int result = useMethods.updatecode(emailaddress, code);
		 * if(result>0) { String codes = useMethods.code(emailaddress);
		 * System.out.println(codes); session.setAttribute("code", codes);
		 * response.sendRedirect("forgotpassword2.jsp"); } else {
		 * response.sendRedirect("login.jsp"); }
		 */
		String inputemailaddress = request.getParameter("emailaddress");
		String emailaddress = (String)session.getAttribute("emailaddress");
	if(inputemailaddress.equals(emailaddress)) {
		response.sendRedirect("forgotpassword3.jsp");
	}else {
		request.setAttribute("msg", "���������������");
		request.getRequestDispatcher("/forgotpassword2.jsp").forward(request, response);
	}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
