package alowsea.com.dao;

import alowsea.com.entity.Users;

public interface Mothods {
public int register(Users users);
public Users login(String username,String password);
public int queryemail(String emailaddress);
public String emailaddress(String username);
public int updatecode(String emailaddress,String code);
public String code(String emailaddress);
public int updatepassword(String username,String password);
}
