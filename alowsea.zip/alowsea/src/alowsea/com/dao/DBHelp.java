package alowsea.com.dao;

import java.sql.DriverManager;

import java.sql.Connection;

public class DBHelp {
	public static Connection getConnection() {
		
		/*
		 * Connection connection = null; try { String url =
		 * "jdbc:mysql://127.0.0.1:3366/alowsea";
		 * Class.forName("com.mysql.jdbc.Driver"); connection =
		 * DriverManager.getConnection(url, "root", "root");
		 * 
		 * System.out.println(connection); } catch (Exception e) { e.printStackTrace();
		 * }
		 * 
		 * return connection;
		 */
		 

		Connection connection = null;

		try {
			// ��������
			Class.forName("com.mysql.jdbc.Driver");
			// ��ȡ����
			String url = "jdbc:mysql://localhost:3306/alowsea";
			String user = "root";
			String password = "root";
			connection = DriverManager.getConnection(url, user, password);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return connection;

	}
}
