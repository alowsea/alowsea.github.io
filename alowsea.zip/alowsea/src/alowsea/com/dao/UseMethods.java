package alowsea.com.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.catalina.filters.AddDefaultCharsetFilter;

import alowsea.com.entity.Users;

public class UseMethods implements Mothods {
	DBHelp dbHelp = new DBHelp();
	Connection connection = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	String emailaddress;
	String code;
	int result;

	@Override
	public int register(Users users) {
		// TODO Auto-generated method stub
		connection = dbHelp.getConnection();
		String sql = "INSERT INTO users(username,password,emailaddress) VALUES (?,?,?)";
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, users.getUsername());
			ps.setString(2, users.getPassword());
			ps.setString(3, users.getEmailaddress());
			result = ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public Users login(String username, String password) {
		// TODO Auto-generated method stub
		connection = dbHelp.getConnection();
		String sql = "select username,passWord from users where username = ? and password = ?";
		Users users = null;
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			rs = ps.executeQuery();
			while (rs.next()) {
				String userName = rs.getString("username");
				String passWord = rs.getString("passWord");
				users = new Users(userName, password);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return users;
	}

	@Override
	public int queryemail(String emailaddress) {
		// TODO Auto-generated method stub
		connection = dbHelp.getConnection();
		String sql = "select * from users where emailaddress = ?";
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, emailaddress);
			rs = ps.executeQuery();
			if (rs.next()) {
				result = 1;
			} else {
				result = 0;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public String emailaddress(String username) {
		// TODO Auto-generated method stub
		connection = dbHelp.getConnection();
		String sql = "SELECT emailaddress FROM users WHERE username = ? ";
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, username);
			rs = ps.executeQuery();
			while (rs.next()) {
				emailaddress = rs.getString("emailaddress");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return emailaddress;
	}

	@Override
	public int updatecode(String emailaddress, String code) {
		// TODO Auto-generated method stub
		connection = dbHelp.getConnection();
		String sql = "UPDATE users SET CODE = ? WHERE emailaddress = ? ";
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, code);
			ps.setString(2, emailaddress);
			result = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public String code(String emailaddress) {
		// TODO Auto-generated method stub
		connection = dbHelp.getConnection();
		String sql = "SELECT CODE FROM users WHERE emailaddress = ? ";
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, emailaddress);
			rs = ps.executeQuery();
			while (rs.next()) {
				code = rs.getString("code");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return code;
	}

	@Override
	public int updatepassword(String username, String password) {
		// TODO Auto-generated method stub
		connection = dbHelp.getConnection();
		String sql = "UPDATE users SET password = ? WHERE username = ?  ";
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, password);
			ps.setString(2, username);
			result = ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

}
