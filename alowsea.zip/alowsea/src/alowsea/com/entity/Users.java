package alowsea.com.entity;

public class Users {
private String username;
private String password;
private String emailaddress;
public Users() {
	super();
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getEmailaddress() {
	return emailaddress;
}
public void setEmailaddress(String emailaddress) {
	this.emailaddress = emailaddress;
}
public Users(String username, String password, String emailaddress) {
	super();
	this.username = username;
	this.password = password;
	this.emailaddress = emailaddress;
}
public Users(String username, String password) {
	super();
	this.username = username;
	this.password = password;
}

}
