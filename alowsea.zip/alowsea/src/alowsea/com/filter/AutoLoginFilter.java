package alowsea.com.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.jasper.tagplugins.jstl.core.If;

import alowsea.com.dao.UseMethods;
import alowsea.com.entity.Users;

@WebFilter("/homepage.jsp")
public class AutoLoginFilter implements Filter {
	public void destroy() {
		// TODO Auto-generated method stub
	}
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
	    HttpServletRequest request = (HttpServletRequest)req;
	    HttpServletResponse response = (HttpServletResponse)resp;
        String cookie_username = null;
        String cookie_password = null;
        Cookie[] cookies = request.getCookies();
        if(cookies!=null) {
        	for(Cookie cookie:cookies) {
        		if(cookie.getName().equals("cookie_username"));
        		cookie_username = cookie.getValue();
        		if(cookie.getName().equals("cookie_password"));
        		cookie_password = cookie.getValue();
        	}
        }
    	if(cookie_username !=null && cookie_password !=null){
    	HttpSession session = request.getSession();
    	Users users = null;
    	UseMethods useMethods = new UseMethods();
    	useMethods.login(cookie_username, cookie_password);
    	if(users != null) {
    		session.setAttribute("users", users);
    	}
    	}
    	chain.doFilter(req, resp);
	}

	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
