package alowsea.com.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebFilter("/registerServlet")
public class zhengze implements Filter {

	public void destroy() {
		// TODO Auto-generated method stub
	}

	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) resp;
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String pwdagain = request.getParameter("pwdagain");
		String emailaddress = request.getParameter("emailaddress");
		String regUn = "\\w{6,16}$";
		String regPw = "^\\w{6,18}$";
		String regex = "\\w+@\\w+\\.(com|net.cn)";
		if (username.matches(regUn)) {
			System.out.println(4);
			if (password.matches(regPw)) {
				System.out.println(5);
				if (emailaddress.matches(regex)) {
					System.out.println(6);
					chain.doFilter(request, response);
				} else {
					System.out.println(3);
					request.setAttribute("msg", "��������ȷ�������ʽ");
					request.getRequestDispatcher("/login.jsp").forward(request, response);
				}
			} else {
				System.out.println(2);
				request.setAttribute("msg", "������6-18λ����");
				request.getRequestDispatcher("/login.jsp").forward(request, response);
			}
		} else {
			System.out.println(1);
			request.setAttribute("msg", "������6-16λ�û���");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		}

	}

	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
